export { default as BaseOptionChart } from '@/components/charts/BaseOptionChart';
