## stack
- vite
- react
- typescript
- mui


## screenshots
![dashboard](screenshots/dashboard.png)
![user](screenshots/user.png)
![product](screenshots/product.png)
![blog](screenshots/blog.png)
![signin](screenshots/signin.png)
![signup](screenshots/signup.png)
